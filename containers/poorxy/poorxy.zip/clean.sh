#!/bin/sh

docker container stop poorxy1-active && \
 docker image rm poorxy1:latest
